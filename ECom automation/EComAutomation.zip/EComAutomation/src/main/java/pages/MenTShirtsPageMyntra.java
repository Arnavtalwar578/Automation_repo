package pages;
import java.time.Duration;
import java.util.List;
import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MenTShirtsPageMyntra {
	
	WebDriver driver;
	By brandSearchOption = By.xpath("//*[@id=\"mountRoot\"]/div/main/div[3]/div[1]/section/div/div[3]/div[1]/span");
	By branchSearchBox = By.xpath("//input[@class='filter-search-inputBox' and @placeholder='Search for Brand']");
//			By.xpath("//*[@id=\"mountRoot\"]/div/main/div[3]/div[1]/section/div/div[3]/div[1]/input");
	By vanHeusenOption = By.xpath("//label[text()='Van Heusen']");
//			By.xpath("//*[@id=\"mountRoot\"]/div/main/div[3]/div[1]/section/div/div[3]/ul/li[1]/label/div");
	By productCards = By.xpath("//div[@class='search-searchProductsContainer row-base']"); 
//			By.xpath("//*[@id=\"desktopSearchResults\"]/div[2]/section/ul");
	
	public MenTShirtsPageMyntra(WebDriver driver) {
		this.driver = driver;
	}
	
	public void filterByBrand(String brandName) {
		driver.findElement(brandSearchOption).click();
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(branchSearchBox));
		searchBox.sendKeys(brandName);
		wait.until(ExpectedConditions.elementToBeClickable(vanHeusenOption)).click();
	}
	
	public List<ProductMyntra> getDiscountedProducts() {
        List<ProductMyntra> productList = new ArrayList<>();
        List<WebElement> products = driver.findElements(productCards);
        for (WebElement product : products) {
            String name = product.findElement(By.xpath("//div[@class='product-product']")).getText();
            String link = product.findElement(By.cssSelector("a")).getAttribute("href");
            double price = Double.parseDouble(product.findElement(By.xpath("//div[@class='product-product']")).getText().replace("Rs. ", "").replace(",", ""));
            int discount = Integer.parseInt(product.findElement(By.xpath("//div[@class='product-discountPercentage'")).getText().replace("% OFF", "").trim());
            productList.add(new ProductMyntra(name, link, price, discount));
        }
        Collections.sort(productList);
        return productList;
	
	

}
}
