package pages;

public class ProductMyntra implements Comparable<ProductMyntra>{
	String name;
	String link;
	double price;
	int discount;
	
	public ProductMyntra(String name,String link,double price,int discount) {
		
		this.name = name;
		this.link = link;
		this.price = price;
		this.discount = discount;
		
	}

	@Override
	public int compareTo(ProductMyntra o) {
		// TODO Auto-generated method stub
		return o.discount - this.discount;
	}
	
	@Override
	public String toString() {
		return "Product Name: " + name + ", Price: Rs. " + price + ", Discount: " + discount + "%, Link:" + link;
	}
	

}
